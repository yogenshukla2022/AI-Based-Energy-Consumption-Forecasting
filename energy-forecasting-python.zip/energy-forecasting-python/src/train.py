
import argparse
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import tensorflow as tf

def load_data(path):
    df = pd.read_csv(path, parse_dates=['timestamp'])
    df = df.sort_values('timestamp').reset_index(drop=True)
    return df

def create_sequences(values, window=24):
    X, y = [], []
    for i in range(window, len(values)):
        X.append(values[i-window:i])
        y.append(values[i])
    X = np.array(X)
    y = np.array(y)
    return X, y

def build_model(input_shape):
    model = tf.keras.Sequential([
        tf.keras.layers.LSTM(64, return_sequences=True, input_shape=input_shape),
        tf.keras.layers.LSTM(32),
        tf.keras.layers.Dense(1)
    ])
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    return model

def main(args):
    df = load_data(args.data)
    features = df[['consumption','temperature']].values.astype('float32')
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(features)
    # we predict consumption only (col 0), but include temperature as exogenous feature
    X_all, y_all = create_sequences(scaled, window=args.window)
    # X_all shape: (n, window, features)
    # We'll predict the consumption column (first feature)
    # Use last dim as features already present
    X = X_all
    y = y_all[:,0]  # consumption column
    split = int(0.8 * len(X))
    X_train, X_val = X[:split], X[split:]
    y_train, y_val = y[:split], y[split:]
    model = build_model((X.shape[1], X.shape[2]))
    model.fit(X_train, y_train, validation_data=(X_val, y_val), epochs=args.epochs, batch_size=32, verbose=1)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    model.save(out_path)
    # save scaler
    import joblib
    joblib.dump(scaler, out_path.parent / 'scaler.pkl')
    print(f'Saved model to {out_path}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=str, default='data/sample_energy.csv')
    parser.add_argument('--out', type=str, default='models/lstm_model')
    parser.add_argument('--window', type=int, default=24)
    parser.add_argument('--epochs', type=int, default=3)
    args = parser.parse_args()
    main(args)
