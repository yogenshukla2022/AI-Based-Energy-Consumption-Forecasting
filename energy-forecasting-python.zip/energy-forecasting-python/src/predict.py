
import argparse
import numpy as np
import pandas as pd
from pathlib import Path
import joblib
import tensorflow as tf

def load_last_window(path, window=24):
    df = pd.read_csv(path, parse_dates=['timestamp']).sort_values('timestamp').reset_index(drop=True)
    features = df[['consumption','temperature']].values.astype('float32')
    return features[-window:]

def main(args):
    scaler = joblib.load(Path(args.model).parent / 'scaler.pkl')
    model = tf.keras.models.load_model(args.model)
    last = load_last_window(args.data, window=args.window)
    scaled = scaler.transform(last)
    X = np.expand_dims(scaled, axis=0)  # shape (1, window, features)
    preds = model.predict(X)
    # preds are scaled consumption; but we saved scaler for both features; inverse transform
    # build fake row to inverse transform
    pred_scaled = np.hstack([preds.reshape(-1,1), np.zeros((preds.shape[0],1))])
    inv = scaler.inverse_transform(pred_scaled)
    predicted_consumption = inv[0,0]
    print(f'Predicted consumption for next step: {predicted_consumption:.2f}')
    return predicted_consumption

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, default='models/lstm_model')
    parser.add_argument('--data', type=str, default='data/sample_energy.csv')
    parser.add_argument('--window', type=int, default=24)
    args = parser.parse_args()
    main(args)
