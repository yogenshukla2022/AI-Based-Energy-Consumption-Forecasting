
# Energy Consumption Forecasting (Python)

This repository contains a simple end-to-end project to forecast hourly energy consumption using an LSTM model (TensorFlow).
It uses a synthetic dataset (`data/sample_energy.csv`) so you can run experiments immediately.

## Quickstart

1. Create & activate a virtual environment
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

2. Train the model (will save to `models/lstm_model`):
```bash
python src/train.py --data data/sample_energy.csv --out models/lstm_model --epochs 5
```

3. Predict (uses last 24 hours to forecast next hour):
```bash
python src/predict.py --model models/lstm_model --steps 1
```

## Project structure
- `data/sample_energy.csv` : synthetic hourly energy + temperature
- `src/train.py` : training script (LSTM)
- `src/predict.py` : prediction script using saved model
- `models/` : where trained models are saved
- `notebooks/` : starter notebook
- `tests/` : simple pytest

