
from src.train import load_data, create_sequences
import os
def test_load_create():
    df = load_data('data/sample_energy.csv')
    assert not df.empty
    X,y = create_sequences(df[['consumption','temperature']].values.astype('float32'), window=24)
    assert X.shape[0] > 0
